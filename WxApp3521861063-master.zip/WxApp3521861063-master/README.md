>演示功能

![image](https://github.com/OnTheWay1991/WxApp3521861063/blob/master/image2/home.jpg?raw=true)
![image](https://github.com/OnTheWay1991/WxApp3521861063/blob/master/image2/order.png?raw=true)
![image](https://github.com/OnTheWay1991/WxApp3521861063/blob/master/image2/user.png?raw=true)
![image](https://github.com/OnTheWay1991/WxApp3521861063/blob/master/image2/buy.png?raw=true)
